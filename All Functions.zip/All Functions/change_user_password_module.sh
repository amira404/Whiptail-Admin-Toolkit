#!/bin/bash

target_user=$(whiptail --title "Update User Password" --inputbox "Enter the username:" 8 50 3>&1 1>&2 2>&3)

if id "$target_user" &>/dev/null; then
    new_pass=$(whiptail --title "Set New Password" --passwordbox "Enter the new password for $target_user:" 8 50 3>&1 1>&2 2>&3)
    echo "$new_pass" | passwd "$target_user" --stdin
    whiptail --title "Password Changed" --msgbox "Password successfully updated for '$target_user'." 8 50
else
    whiptail --title "User Not Found" --msgbox "The user '$target_user' does not exist in the system." 8 50
fi
